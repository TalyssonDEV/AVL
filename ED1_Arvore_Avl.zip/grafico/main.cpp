#include <iostream>
#include "backend.h"
#include "gconio.h"
using namespace std;

void caracter(int tam)
{
    char a[] = {"  "};
    for(int x=0; x<tam; x++)
    {
        cout<<a[x];
    }
}
void bolaMenor(int coluna, int linha, int color)
{
    textbackground(color);
    gotoxy(coluna,linha++);
    cout<<"    ";
    gotoxy(coluna -1,linha++);
    cout<<"  08  ";
    gotoxy(coluna,linha++);
    cout<<"    ";
}
/*void bola(int coluna, int linha, int color)
{
    textbackground(color);
    gotoxy(coluna,linha++);
    cout<<"     ";
    gotoxy(coluna -1,linha++);
    cout<<"       ";
    gotoxy(coluna -1,linha++);
    cout<<"       ";
    gotoxy(coluna -1,linha++);
    cout<<"       ";
    gotoxy(coluna,linha++);
    cout<<"     ";
}*/
void bolaComSombra(int coluna, int linha)
{
    bolaMenor(coluna,linha,BLACK);
    bolaMenor(coluna-1,linha-1,BLUE);
}
void apagaBola(int coluna,int linha)
{
    bolaMenor(coluna,linha,WHITE);
    bolaMenor(coluna-1,linha-1,WHITE);
}
void movimentarBola(int coluna,int linha)
{
    for(int x=0; x<9; x++)
    {
        apagaBola(coluna,linha);
        coluna++;
        linha ++;
        bolaComSombra(coluna,linha);
        Sleep(50);
    }
}
void transicao(int coluna, int linha, char direcao,int tam)
{
    tam <1? tam = 1: tam = tam;
    if(direcao == 'd')
    {
        for(int x =0; x<tam; x++)
        {
            gotoxy(coluna,linha);
            textbackground(DARKGRAY);
            cout<<"      ";
            ///caracter(tam);
            coluna+=5;
            linha++;
            Sleep(50);
        }
    }
    else
    {
        for(int x =0; x<tam; x++)
        {
            gotoxy(coluna,linha);
            textbackground(DARKGRAY);
            cout<<"      ";
            ///caracter(tam);
            coluna-=5;
            linha++;
            Sleep(50);
        }
    }

}
void menu(int op)
{
    //int op;
    int coluna = 73;
    int linha = 1;
    int tam = 3;
    int aux = 0;
    int auxL = 0;
    int anterior_colunaa,anterior_linhaa,anterior_coluna,anterior_linha;
    textbackground(WHITE);
    system("cls");
    ///do
    ///{
        if(tam<3 && tam > 0)
        {
            aux-=6;
            auxL -=1;
        }


        switch(op)
        {
        case 1:

            bolaComSombra(coluna,linha);
            break;
        case 2:
            transicao(coluna-6, linha+3,'e',tam);
            linha+=(7+auxL);
            coluna-=(19 +aux);
            tam--;
            bolaComSombra(coluna,linha);

            break;
        case 3:
            transicao(coluna+4, linha+3,'d',tam);
            linha+=(7 + auxL);
            coluna+=(21 + aux);
            tam--;
            bolaComSombra(coluna,linha);
            break;
        case 4:
            ///coluna =  ((73 -19) + aux);
            anterior_coluna = coluna;
            anterior_linha  = linha;

            transicao(coluna+4, linha+3,'d',tam);
            linha+=(7+auxL);
            coluna-=(19 +aux);
            bolaComSombra(coluna,linha);

            coluna = anterior_coluna;
            linha  = anterior_linha;

            transicao(coluna-6, linha+3,'e',tam);
            linha+=(7 + auxL);
            coluna+=(21 + aux);
            bolaComSombra(coluna,linha);

            tam--;
            break;

        case 5:
            coluna =  ((73 -13) + aux);
            anterior_coluna = coluna;
            anterior_linha  = linha;

            transicao(coluna+4, linha+3,'d',tam);
            linha+=(7+auxL);
            coluna-=(19 +aux);
            bolaComSombra(coluna,linha);

            coluna = anterior_coluna;
            linha  = anterior_linha;

            transicao(coluna-6, linha+3,'e',tam);
            linha+=(7 + auxL);
            coluna+=(21 + aux);
            bolaComSombra(coluna,linha);

            tam--;

            break;


        case 6:

            coluna = (73 + 32 + aux);
            linha = anterior_linha;
            anterior_colunaa = coluna;
            anterior_linhaa  = linha;

            transicao(coluna+4, linha+3,'d',tam);
            linha+=(7+auxL);
            coluna-=(19 +aux);
            bolaComSombra(coluna,linha);

            coluna = anterior_colunaa;
            linha  = anterior_linhaa;

            transicao(coluna-6, linha+3,'e',tam);
            linha+=(7 + auxL);
            coluna+=(21 + aux);
            bolaComSombra(coluna,linha);

            tam--;
            break;

        }
    ///}
    ///while(op != 9);
}
int main()
{


    Node* raiz = NULL;
    int coluna = 73;
    int linha = 1;
    int valor;

    do
    {
        cout<<"\nInsira um valor na Arvore: ";
        cin>>valor;
        raiz = inserir(raiz,valor);
        mostra(raiz);

    }while(valor != 99);

    gotoxy(coluna,linha+25);
    cout<<"\nFinalizado!";
    return 0;
}
